# EPISODE 0.1: "THE NAKED FACE"

**QL Position:** #1 — Split / Genesis / Differentiation
**From the QL Doc:** Axis 1 — but restructured as: the definitive episode on WHAT AN ARCHETYPE IS
**Function:** Defines "archetype" at its deepest — spectral, harmonic, psychoid. Establishes the Antichrist as archetypal IMAGE through characterological portraiture. Establishes the archetype-as-such as irrepresentable pattern. Demonstrates the spectral principle via the quaternary animal series. Wraps the whole in psychic facticity as the epistemic gateway. Frames language/etymology as sharing the attractor-instantiation dynamic.
**Duration Target:** 25–30 minutes
**Tone:** Intimate, layered, building. This is the intellectual foundation for everything that follows.

**Passages used in Episode 0.0 (do not repeat):**
- Symbological Contemplation, line 41 ("A good living symbol has limitless depths...")
- Compassion Throne, line 92
- Good Man / Bad Man, lines 289–293
- Hermit Image, line 3

**Passages pushed to Episode 0.2 (QL #2, historical-energetic position):**
- Answer to Job / Aion, line 93
- Collective Dimension, line 158
- "You Are Dead to Me," line 152
- The Two Brothers, lines 227–231
- The Symbol of Suffering and Mergence, line 149

---

## MOVEMENT 1: THE POEM — OPEN

> *Words reveal and re-conceal the real — they make up the makeup that adorns the face of the world, and at best accentuate and enhance the natural contours of its beauty, at worst comfort it into a clownish facade — words when cleared from the pores reveal the sheet beneath the score — words reapplied where cleanliness is denied weave a bandage over sores — re-presenting for disguise, naked bare with no surprise, realise the seer dies when faced with mind's reflected sight*

---

## MOVEMENT 2: THE SEER — PSYCHIC FACTICITY AS GROUND

### READ — "On Being Seen" (line 20):

> On being seen — It became clear in the course of my inner dialogue with the I-image that the only way to be seen is to define one self through qualities, such that one may be sighted, and these qualities must be relational, having the capacity to appeal to another. Now there may well be objective qualities of awareness or pure consciousness, but these are subsidiary to the unity and oneness that characterise it's fidelity. They are not predefined and cast out into the world in the hopes of being stumbled upon as a means of ensnaring another in some image. The Self births the self, an image which can be traded as a meme in the noosphere, and because of this development it can crave to be seen, only because it depends upon the Self in order for it to be instantiated, whether that be the Self that burns beneath the objects of my life, or those of another. If this attention from the Self doesn't arrive, it festers and grumbles in potentiality, in latency. All that is untrue is the doing of latency in the sense of lag. Lag implies a dislocation from presentness, which is true Being. This is why we flounder when we are out of the pocket, out of our groove, that rhythm that lag, in the forms of rushing and dragging, is measured against. Rushing and dragging are but positive and negative latencies. No, to be seen is to see ones Self, and to see ones Self is simply to see, to attend to what is ever arriving and departing in the sea of change that assails us, that we sail upon. Being is being Being; Consciousness is conscious of consciousness. Yet these two, from a Taoist perspective, are conceptualised as non-being, i.e non-manifest but ultimately real. Because non-manifest, no image nor concept may encapsulate or exhaust their essence, existence nor total significance. Between this non-being and being, the sea of change, arises the possibility of being seen or not being seen, of being an object for some mind or perceiving subject, or not. If there is no object called I, could this demand to be seen, to be consumed by a gaze, be consummated? Just as the knife cannot cut into itself, seeing can never see itself — but seeing this has a profound effect on us. We stop seeking an object as the achievement of our divine seeing; it is enough to become the Seer that has always been but always been seen through. No object holds or contains seeing, but all objects are objects solely because they are seen. Because they depend equally upon being seen, there is only separation between objects as far as we see it, and nothing inherent to objects other than their being seen. Between one location of the Seer and another, between self and other, is but a wafer thin compartmentalising illusion of objective identity, the "personal" body-mind. This need not be seen off, but rather needs to be seen through, for only one Seer makes appearance. Far from solipsistic, no other is denied in this — the Seer is every self, which become every other, taken up back into their nature, clear cognisant Oneness.

### Context:

- The lower case self self-identifies as "I am here" — its identity is "I am out here, in here," split by the boundary it can't see past. The upper case Self self-identifies as "I know that I am here" — its identity is "Here; that I am." The self is in the world; the Self is the space the world is in. The seer dies when it realises it was always the seeing.
- Jung: "I don't believe — I know." Not a metaphysical claim from above but an empirical claim from below. The psyche produces FACTS — dreams, visions, numinous experiences. The occurrence is not debatable. Content is symbolic; the referent is discussable; the event is real.
- This is the epistemological gateway for everything that follows. If inner experience is not valid, there is no access to archetypes, no shadow work, no symbolic contemplation. The prerequisite for working with the unconscious is according psychic facticity its proper weight.
- The hermeneutics of suspicion (reductive filtering of testimony before it's heard) vs. phenomenological epoché (bracket the "really exists" question, attend to the phenomenon as given).
- When you do this: convergent structure across traditions becomes apparent. Con-spirare — breathing together. Not syncretic forcing but convergent encounter with the same topology of consciousness.

---

## MOVEMENT 3: THE SPECTRAL DEFINITION OF ARCHETYPE

*This movement establishes what an archetype IS — not as academic definition but as felt reality.*

### READ — "What Is the Anti-Christ?" (line 243):

> What is the Anti-Christ? From this perspective it is a movement in the life of this planet, older than Christendom but coloured by its name, expressing a certain set of transformational principles carried in, through and out by Man as such. It is Man's symbolic psychic activity and symbolic behavioural activity in the world framed as a psycho-spiritual struggle. Beyond any particular cultural context or situationally rooted understanding or behaviour, it is a symbol for the essence of Man-in-the-world and the challenge that Man presents to the world and Himself, the challenge of suffering ignorance and suffering toward understanding, and most of all the challenge of understanding the suffering entailed by our difference and exceptionality upon the face of the Earth. It is a symbol in the truest sense; a living centre through which meaning, and thus the very ground of understanding, finds its way to our capacity to consider, mysteriously enough. It is an empty vessel to hold in hand the contradictions that war in Man's care, mediating the differences that structure what matters to us in varying degrees, uniting the distinctions which define our all-too-human experience, an ever groping synthesis of the contradictions that undergird the range and region that is Man's unique being. Therefore, the Anti-Christ is what Man is making of himself, and is, as such, blind to what God is making of Man.

### Context:

- *anti* (Greek): against, opposite, IN PLACE OF, substitute. The Antichrist stands in Christ's place when Christ's living spirit crystallises into doctrine and idol.
- "A movement in the life of this planet" — not a person, a group, a conspiracy. A MOVEMENT. Like a tectonic force, an atmospheric pressure.
- "A symbol in the truest sense" — the archetype-as-such is not the symbol. The symbol is the TRACE of the archetype, the way an orbit traces the attractor.
- Van Eenwyk (*Archetypes and Strange Attractors*, 1997): archetypes function like strange attractors in nonlinear dynamics. Never reached, never fully instantiated — but they shape every trajectory in their basin. Self-similar at every scale (fractal) but never identical. The symbol is the basin of attraction.
- The distinction: archetype-as-such = the attractor, irrepresentable, empty pattern. Archetypal image = the trajectory, the orbit, the specific manifestation in this culture, this psyche, this dream.
- This means: the Antichrist is not any one of its images. It is the PATTERN that generates them all. Each image orbits the same attractor. No single image exhausts the archetype. All of them together begin to reveal its shape.

### READ — "The Emptiness of the Symbol" (line 282):

> The emptiness of the symbol — Like an open intersection beckoning travellers to a heart attuned to inflows hailing from the furthest extents of the cardinal directions, the symbol is a place of meetings and passings. Unto all it is the value of capacity, the value of an empty or emptied space that opens out onto our faring, as a flower opens out to release its scent and beckons forth the activity of Nature. What meets at and eventually alights upon our open symbol are meanings, quanta of relevance and their concomitant qualities of resonance. Upon emptiness develops self-organised communities of meaning, built on inter-operating significances that make of the open intersection a settlement and culture, crafting a character that is ever in the throws of the process of definition and capturing. Only then may custom and convention of meaning form, making of the ambiguity of emptiness the definition of a habitual, recognisable manifestation of being. Emptiness, thus, is no more vacuum, but an invitation to and promise of the potentiality of life and life's myriad ways as a means to order and beauty. This is the fundamental understanding that opens the way to symbological contemplation; moreover, it opens the way from the symbol to the timeless wisdom of the spirit, the wisdom of Truth's rooting in mystery or the emptiness of phenomena. Symbological understanding makes of all apparently fixed, defined and inherent essences a phantom, and allows what appears to us as distinct natures the opportunity to engage in an ever provisional project of free association, free movement and free exchange of significances, a kind of creative activity that gives flight to unique communions of unique meanings, allowing relevance to always find redefinition and freshness, i.e renewed relevance. Ultimately, conceptual understanding recedes in humility when faced with its ground, empty presence, that living significance that is ontological bedrock, dependable yet utterly independent, true and sure yet totally indefinite. The true symbol stands between the world of concept and that of utter emptiness; it partakes of empty nature, opening out beyond itself through participation and devotion to the mystery, but holds out tendrils of recognisable conceptual and aesthetic patterning such that our cognising consciousness, our "meta-cognition", based on thought's syntactical structure of signification, can array about the dark core of mystery constellations that bear the effects of that mystery's bivalent capacity to intelligently and meaningfully organise, whilst grounding this work in groundless being. Though a kind of specifying and speciation, the symbol's life is always a movement between specification and creative ambiguity, thus through the mystery meaning can live out its evolutionary necessity, developing as a result of a fundamentally transcendent symbolic core which allows for the acute destiny of any symbol as a given meaning or assemblage thereof, whilst leaving its essence free and undefined. Thoroughly grounded in the groundless, symbological contemplation is a party, a participatory activity in which meaning is invited to dance with itself and foster new inner relations — the word is allowed to take flight. This is an antidote to the stagnation of significations that occurs through the rigidification of conceptual conventions within a cultural context. This stagnation is a fossilisation of Truth, which would be most free when allowed to find itself freshened by the flow of life, with the reality of immutable changefulness.

### Context:

- "Self-organised communities of meaning" — this IS the strange attractor's basin. Meaning self-organises around the empty centre without being dictated by it. The attractor doesn't CAUSE the orbit — it SHAPES it. This is why archetypes feel both discovered and created.
- "A party, a participatory activity" — the symbol invites engagement, not passive reception. You enter the basin of attraction. You orbit. Your orbit adds to the community of meaning.
- The harmonic principle follows from this: if the symbol is an intersection where meanings from all directions meet, then invoking one meaning brings its resonances — its overtones — with it. The symbol is a CHORD, not a note.
- Pauli and Jung's deeper project: the psychoid nature of number. Number sits at the intersection of inner and outer — simultaneously subjective (numinous, meaningful) and objective (mathematical, invariant). Archetypes-as-such, if they are the irrepresentable patterns that generate BOTH psychological images AND physical structures, sit at this psychoid level. They are "pure mathematically precisely poetic-poietic intelligence structures" — form-generating principles that are simultaneously rigorous and creative.

---

## MOVEMENT 4: THE DEVIL AS ARCHETYPAL IMAGE — CHARACTEROLOGICAL PORTRAITS

*Now we SHOW the spectral principle in action by tracing the Devil through his many images in the Book. Lead with the being. Let the viewer encounter the CHARACTER before the theory.*

### READ — "The Showman" (line 224):

> The great Showman, an utter show-off, who won't show up anywhere that he can't show up the rest. His show must go on, lest he is shown what lays behind the curtain, that realm where the showlights don't reach. Demanding a good showing, he believes he shows the way and tolerates nobody who might attempt to show him the light; he cannot bear to be out shone. Every interaction of his is a showdown, and he would hate to be shown the door that leads out of the ring. He too must be the showstopper, even though it's always showtime. Always on show and playing to the crowd, he resists that inevitable moment where it becomes clear that it's all for show. He'll gloat and showboat to let it be known that he is the top dog. Even when we think the show is over, for him it is never truly seen off, never given over to the tide of reality. It's not only all for show, it is all show, and alone he cannot close it. Man alone can close the Devil's show, or else we'll be drafted into the show notes, for the Showman, though so much he has shown Man, makes of our humanity a no-show. We must show him what we are made of, raw unscripted Truth, which no display of the senses may show up. For all too long we have been one of his show pieces, an ornament of his action. We must show to his final act, which is to realise in himself that which is beyond all action and acting.

### READ — "The Gifted Child and His Playmates" (lines 170–176):

> He is a gifted child, a young savant, master of techne of all sorts, a prodigious prodigy bankrolled for his projects by parents of the greatest wealth but yet who remain "angel investors", aloof and at a distance, who have left the child out to be raised by the wolves, so to speak, who are his feral, beastly au pairs. He thinks, as do his peers, that he has all he could ever want, and can do whatever he could want to do. But his heart is unsatisfied; he craves unknowingly the presence and love of his parents, not just the effects of their riches. So he goes on crafting, wielding technique and instrumental skill in the service of a heart that just wants to be at home with Mum and Dad.

> One of his many skills includes the art of chemistry. He is a great divider, distiller and synthesiser, a deviser of medicaments and tonics, but none of his many potions could heal his broken heart. Some of them knock him out and numb him, others stimulate him so that he can work all day and night, some send him on wild trips through dream, fantasy and spurious, numinous imaginings of unknown, exotic lands. Never do his concoctions bring him nourishment.

> An inherently lonely child, all his playmates are lured into his house, and they are mesmerised by his trappings, his gadgets, toys and projects, his playhouse of make-believe workings, but he cannot resonate with any of them because he doesn't share their innocent joy. His friendship tends toward their corruption and eventual destruction. His heart is sick and hard, theirs vital and vulnerable, and thus they enter into a land of danger in his abode. They are transfixed by his many accoutrements, not knowing they are additions upon his primal negativity. They come to envy what he has, not realising that all he has is part of an attempt to discover or produce something that could let him experience love, and which never bring to him what he so direly needs.

> He is determined like headstrong youth, and will work to no end to craft the love he unknowingly seeks. Truly he works to no end, for there is no end in sight when your end is an impossibility to your means. You cannot craft love, but you can express it through your works, give it permission to spread its wings and take flight in your life such that it may find, in your experiences, those base materials out of which love's nest is crafted, such that love may raise its children, joy and peace, in your very being. But he cannot see the simple truth that you cannot craft that which is uncreated, and his young heart, stuck in a broken home, cannot admit its determination is, after all displays, utterly worthless.

### READ — "The Hermaphrodite and the Family Drama" (lines 60, 36–37):

> He's been having us on. The Devil is not exactly Christ's brother; he is also Christ's sister! The Devil's masculinity is to a degree false, a facade and insubstantial countenance. What appears to be strength and activity, classically masculine principles, is closer to a show of force, a forcing of things into ways unnatural to them, rather than a true play of forces as Nature so magnificently displays. He is a small dog yapping at the gate. He did not transition into his apparent masculinity, nor did he by any procedure become a man; from the off he's been a true hermaphrodite. But unlike the divine syzygy, which expresses the unity of life's fundamentally gendered forces, his hermaphroditism is a con-fusion, a denial of one identity in lieu of the other. His phallus is non-productive, and his horns are tacked on. In the first case, what is represented is the impotence of his creative function, though the existence of it taunts him. For this reason he is neurotic about privacy, hiding his privates whilst jealously invading the privacy of others. In the second case, where his horns represent the power of duality, their being tacked on shows that the only power duality holds is the power of a "put on", a joke or hoax. In his con-fusion he cannot accept himself because he cannot unify himself. He is, in this sense, the imbalance and dysregulation of the genders, those primal forces which engender all intelligibility through the harmonious interrelation and dependent co-origination of opposites. He blames his parents, the original image of the opposites, for his confused state. This confusion is not a state of mind but a state of being; he is the flipside of the divine paradox, divine incoherence. One's heart must go out to this tortured soul.

> The Devil needs compassion. Like a petulant adolescent who's been kicked out by their parents, he is a de facto orphan, unwillingly emancipated. He is like modern Man; we are born, having emerged out of Nature's cosy womb into uncanny freedom, held no longer by her generous soul which had wrapped about our ancestors the comforting blanket of a micro-cosmos imbued with divine meaning. Suddenly in the open world, naked for the first time, the work of building our microcosm is thrust upon us. We two wayward miscreants, given over to novel realms and fresh responsibilities, Man and the Devil cling to one another for support. We used to look upward in search of divinity, but the fragment of God that has fallen has fallen into our laps. I don't think we could have done anything else but walk with our new companion, especially once it was clear that the Gods had flown the coop. At least he desired to know us; at least he came down to us. Like a daughter fleeing the clutches of a controlling father, we've gone out into cold freedom with little by way of code and compass to guide us toward warmth. Who knows who we may sidle up to for that divine cosiness of love, who we may walk with on our way to knowing our way.

> Leaving behind the parents always comes too soon, and yet never soon enough. Ejected from the Paternal Spirit of utter goodness and perfection, the Devil, eternally arrested in his development, seeks his own path, seeks to break the mould, to exploit the cracks in the system and let in some fresh air. A little slack in the system is actually quite welcomed. We have to make the most of the gaps.

### Context — the spectral range demonstrated:

- In these passages alone: the Devil as Showman, top dog, gifted child, young savant, chemist, lonely playmate, hermaphrodite, orphan, small dog yapping, de facto orphan, petulant adolescent, daughter, companion, wayward miscreant. FOURTEEN distinct image-registers of one being.
- This IS the harmonic principle. No single image is "the Devil." Each is an overtone of the same fundamental. Together they form the chord.
- The family drama (Father/Mother/Devil/Man) is a uniquely METAPHYSICAL strand: the yin-yang dynamic of masculine and feminine IS the Tao, the harmony of the family in principle. Father = intelligent emptiness, space, restraint. Mother = evolving love, matter, productive nature. Their harmony IS divine order. The Devil's hermaphroditism is this harmony's "con-fusion" — the family broken, the principles muddled, neither unified nor properly separated. The Antichrist epoch IS the broken family writ civilisational.
- "You cannot craft love" — the soteriological key hidden inside the characterological portrait. The light compressed within the image.

---

## MOVEMENT 5: THE ARCHETYPE-AS-SUCH — IRREPRESENTABLE PATTERN

*From the images, step back to what generates them.*

### READ — "The Divided Individual and the Fear of Formlessness" (lines 42, 44):

> The devil is the divided individual. In him all codependent dualities exist in a divorced state. He is divided from his deeper Being, soul divorced from God. God is the centre of all selves, but in the devil's divorced state he has cast in himself the illusion that he has become his own centre. This self-centredness causes a paranoid neuroticism, for he believes that his being himself pits all others against him, as God is the whole, including all others. Naturally this leaves the devil always outnumbered, and in response to his feeling besieged on all sides he develops a strategy to control all others, one that seeks to rectify their potential threat to him by way of their being made impotent, or more cunningly, by ceding to him their power. The others have their power by way of their rootedness in Being, their being monopolised by Being. The self-centred devil must enact his own monopolisation if he is to make of himself a centre. His strategy of control is monopolistic in nature because this strategy seeks to appropriate power, not create power. Mono-poly is the nature of wholeness. The devil, father of the unwholesome, works to rectify his sense of unwholeness.

> Unity is already the ground of Being, the natural and necessary coming together of all things prior to their appearance in multiplicity — each fraction of existence entails the entirety of existence. The Devil's self-centred intention is to redefine unity, to build a new unity or "order", one that fundamentally denies the preexistent unity upon which all objects, those he plans to reunify, already depend. This original ground of unity is often referred to as empty, or emptiness, and is empty precisely because it is through its formlessness that forms (objects) are able to appear. The devil fears formlessness deeply. His resistance to formlessness is rooted in his misunderstanding of it as an absence; he simply can't see it because he can't recognise what doesn't have an appearance, per his obsession with appearances. That which is empty and does not appear haunts him because he simply cannot understand it, yet in his heart he knows his denial of it is crude and ineffective — this emptiness is none other than his inmost Self, as is so for all sentient beings. He seeks to build a unity of appearances alone in order that he can pay fealty to his misperception, for it appears to him that, in lieu of an acceptance of that which is empty, all things are truly separate from one another. In his denial of the ground of unity he finds the condition for his project toward a false unity. Fear of being empty leads to fragmentation because that which appears as empty is actually the fullness of Being. In believing himself to be limited to his form, he immediately believes himself to be divorced from the fullness of Being, and from the subsequent feeling of lack he vexingly seeks the unity, denied in his ontological misstep, in and through forms.

### READ — "The Anti-Spectral Rigidity" (line 116):

> Only when life is rooted in the image of no-image may the plenitude of wonders we see as the cosmos take form, only through unitary and limitless formlessness may the countless forms of life coexist as one great cosmic life process. The fault in the Devil's attempt to become God is that he is positively rigid, a definite form or archetype that won't change for anything, and won't allow anything to rest in its own nature, to be what it is. And yet paradoxically, all he wants is to become God, yet he can't because he can't get over himself and forgo his characteristic stubbornness. From this stubbornness comes blame; he projects all his need to change on the world. He thus wants to change the world to suit his twisted vision, and will yield to no other. Somehow though, he is also supremely weak and fickle. He will, at the drop of a hat, with uncanny swiftness, contort his own sight, his beliefs and perspective, just so that he doesn't have to believe his lying eyes when they try to convey to him the invalidity of his self-understanding. He is fickle in regards to belief structure and belief system, which he uses as an ever changeful curtain to black out the light of Truth. He performs about this curtain. His fallen trinity is composed of the light, the veil and the shadow. He stands tall and performs in the light, cowers and plots backstage in the shadows, and masks his plotting and his cowardice with the veil. His cowardice is constituted by his fear of emptiness and his facing up to, overcoming and letting go of this fear would amount to giving him roots in the ground of reality.

### Context — the anti-spectral as the diagnosed condition:

- mono-poly (one-many, Śiva-Śakti): the nature of wholeness. Ambiguous relation, "both relative and absolute, yet neither." The Devil's inversion: ambiguous mono-poly → certain monopoly (line 146). The collapse of paradox into fixity.
- monopoly = mono + *polein* (to sell): sole seller, controller of all exchange. But mono-poly = mono + poly (many): the one that IS the many. The Devil can't hold the ambiguity.
- The Devil manifests spectrally (he IS all fourteen images) but identifies monoscopically (he insists he is "The Thing, the essential form" — line 46). He HAS the harmonic richness but can't HEAR it in himself. His gimbal lock is his refusal to rotate through his own spectrum.
- "His fallen trinity: the light, the veil and the shadow" — a trinitarian structure, but FALLEN. The divine Trinity integrates; the fallen trinity performs, conceals, and plots. Three activities that never meet, never compound into context (the 3→4 failure).
- This is why the symbolic method heals: it restores the spectral character that the Devil's mono-identification refuses.

---

## MOVEMENT 6: THE QUATERNARY ANIMAL SERIES — SPECTRAL DEMONSTRATION

*A focused case study showing the harmonic principle operating through an interlocking family of archetypal images across history.*

### Context from the supporting corpus — the system:

- The fourfold animals of Hermopolis (Hermes' Egyptian city) / the Tetramorph / the four fixed zodiacal signs: Bull, Dog, Eagle, Lion. Each contains a solar-explicate and lunar-hidden aspect:
  - Bull (raw power, conquest) / Ox (refined mastery, Zen ox-herding)
  - Dog-Sheepdog (loyal discipline, guardian) / Wolf (wild autonomy, rebellion)
  - Eagle (solar vision, prophecy) / Owl (lunar wisdom, occult knowledge)
  - Lion (divine kingship, Logos embodied) / Jaguar (shamanic guide, hidden sovereignty)
- Plus position 0 (Lamb/Sheep: sacrifice/passivity) and position 5 (Son of Man / Man the Son: full integration / eternal adolescence)

### The spectral continuum through history:

- **Mithra** (Arian age): balanced integration of all four. Sacrifices the bull externally, embodies ox's discipline. Dog's cosmic loyalty plus wolf's boundary-transgression. Eagle's solar vision plus mystery cult's owl-wisdom. Lion's authority plus jaguar's transformative knowledge.
- **Prometheus** and his brothers — key Jorjani reference (*Prometheus and Atlas*): the four Titan brothers as another quaternary. Prometheus (forethought — the one who steals fire), Epimetheus (afterthought — the one who accepts Pandora), Atlas (endurance — the one who holds up the sky), Menoetius (rash violence — the one Zeus blasts with lightning). Four aspects of the Titanic/Luciferian impulse: forethought, afterthought, endurance, and wrath. Each a harmonic of the same rebellion-against-the-gods fundamental.
- **Milton's satanic throng** — *Paradise Lost* names the diversity: Satan, Beelzebub, Moloch, Belial, Mammon, Mulciber, Azazel. Each embodies a different REGISTER of the fallen — pride, gluttony, wrath, sloth, greed, craft, transgression. Milton understood the spectral principle: the rebellion against heaven isn't one thing, it's a CHORUS of distinct but resonant voices.

### The Venus dynamic:

- Lucifer = the Morning Star = Venus. *Lux ferre*, to carry light. But Venus is also the Evening Star — Hesperus. Same planet, different face depending on whether it rises before the sun (herald of light) or follows the sun (harbinger of darkness).
- Venus (love, beauty, desire, connection) → Mars (war, force, assertion, separation): the planetary pair, the lovers, the complementary. The Venusian impulse toward connection, when disconnected from its source, inverts into Satanic obsession with separation and domination. Beauty becomes temptation. Aspiration becomes hubris.
- This Venus-Mars polarity links back to the salt and pepper: Venus = salt (wisdom-adjacent, crystalline clarity, the jewel of the sea, "the child of the warring elements"), Mars = pepper (scorched earth, brute force, gunpowder, "the king of the rubble").

### READ — "Salt and Pepper / Child of War" (lines 39, 61):

> Our Devil shares somewhat in the nature of salt and pepper — he is the seasoning of life. Salt is the jewel of the sea, its crystalline child, so complex and beautiful, without which the oceans could not have supported life. Without salt the seas would have frozen over gladly, and in their few liquid moments would have been bereft of the buoyancy that lifted life gently from the depths to the land, such that Man has arisen as the salt of the earth, as the free spirit with saline solutions born of our tears for life. Those of us without such solutions may well be salty, for life can leave a strong and overwhelmingly bitter taste. Salt is the family heirloom of earthly nature, the power of elevation descended and deposited in the rocks, carried to the seas by the rains and rivers. Salt is the flavour of the ages passed down the line, the teacher of wisdom's crystalline clarity; salt teaches the balance between wise moderation and good taste. Salt is a symbol of wisdom because it is the child of the warring elements, and war is the father of wisdom. Salt is like earth, structured and solid, married to the rocks in the darkness of the planetary body. Dissolving and disappearing, salt yields to and becomes ubiquitous in the waters which wrest it from its earthly lodgings. Salt then reappears in the heat of fire, revealing itself upon scorched rocks by salty rivers, a magic white working of the sun, alluring to animals and Man alike, dancing like a flame across tongues. And then again we find salt in the coastal air, diffuse in the sea mists that sooth our skin and beckon us toward the fomenting waves and the depths they garnish. Finally, like space/time, salt is a form of delicately spun geometries, echoing the inherent intelligence and complexity, the logic and reason, baked into the fabric of being. Our Devil shares in all these qualities, and as such is wisdom-adjacent. But he also shares in the nature of pepper, the other child of war; scorched earth, blackened rock. Famously the "spice of the rich", the Devil's peppery side is the pock-marked and peppered victor of war, the king of the rubble, winner of the bounty left after conflict. As opposed to the subtle bounty of wisdom, this side of his nature represents the material bounty garnered through brute force. Without pepper the first formulations of gunpowder would not have been successful. Though war is said to be the father of wisdom, too often war is simply the father of war. Ever slippery and mercurial in nature, this is Devil's diabolically dual essence.

> Like salt, the Devil is the child of war, the war of the divine parents, the war of the originary principles, the war of the cardinal directions — he is a self-excluding centre. Like a wildfire, if contained and managed by well kept land and fair weather, he can be a fertile force for a coming boon. If he is left to run rampant in our forests, however, he will devour all the lands. We seem to keep leaving dry sticks strewn across the forest floors, and the winds have been ungodly of late. It doesn't help that he's not shy of mischief, and has a penchant for the flames. He quite enjoys hiding in smoke of his own making. But he lights and fans the flames despite himself. In arrogance he becomes the father of war, for he wishes to play the role of the Father he is estranged from, yet as father he can only create destruction. He creates the same destruction and war upon the Earth as that in Heaven which first rendered him fallen. He lights earthly fires in ode to his origin, as if to recapitulate his birth, but these earthly fires simply burn. Perhaps he wishes to prime the lands for his developing princedom; perhaps he just wants to watch the world go up in smoke. Either eventuality entails the other.

---

## MOVEMENT 7: LANGUAGE AS HARMONIC MEDIUM — FABRICATION AND THE WORD

*Language shares the attractor-instantiation dynamic. Etymology IS harmonics. The Devil's fabrication is a linguistic quality.*

### READ — "Making Up vs. Creating" (line 27):

> His essence is the joy of sin, and sin held the original meaning of "fault" or "error". Though it has deeply moralistic connotations, I'll use it to primarily denote this kind of ontological error making. The magician in the Devil plays itself out through this making of error; he creates the illusion of reality where it is not, thus creating the fault of false understanding. By way of this mechanism, we come to default on Reality. Yet the Devil can only craft an illusory reality, not actually create a new one. He is divine, yes, though fallen and earthly — he cannot change the makeup of things. But what he can do is make things up. One cannot deny how special it is to make something up, conjuring up a new look or image, embellishing upon a story, or even putting together again what has come apart; but none of this is "creation", the founding of a reality. We are always in danger of embellishing to the point that the original is totally lost and we lose that which is being embellished upon.

### READ — "The Icing and the Cake" (line 29):

> Through the Devil, we become vulnerable to the temptation to make the icing the whole cake, and yet still think of it as a cake. Then we have not the specialness of a little adornment, a bit of eye shadow or a spoon of sugar in a cup of tea, but rather the garishness of a face put-on and the sickliness of tea-flavoured syrup, and we lose the essence of what we first had, rather than elevating it. It is this journey from the little nicety to the utterly false that we walk when we lose sight of essence. Essence has a moderating effect on what can change about something, in that it defines the bounds of what constitutes one thing as opposed to another. The more essential an aspect of something is, the more it stands back, the less conspicuous it is, the more mild and subtle it is. The Devil's adornments, however, are crude, flashy and brute, and can quickly weigh heavy on us. Dare I say there's an innocence to the act of bedevilment; the Devil just wants to show us how to make things better, to show us the joy of making a show of things — so often a show is a celebration and appreciation! But often this leads to or requires that we forget how great things are in the first place, in their originality and purity. His leash must be kept short; he is not one to stop readily once the ball gets rolling.

### Context:

- "He cannot change the makeup of things. But what he can do is make things up." The makeup of things (the *kosmos*, the divine order) is untouchable. Making things up (producing cosmetics, spectacles, simulacra) is all the fabricator can do.
- *kosmos* (Greek): order, ornament, THE WORLD — all three meanings at once. The world IS the ornament IS the order. *Cosmetic* (from *kosmetikos*): pertaining to adornment, ordering. The world is the cosmetic of ultimate reality. The cosmos' cosmetic.
- Deep sleep as proof: all beings return to a state of deep sleep — attesting that the entire waking world, my life, my sense of there being a thing at all, is embellishment upon an enduring dark being. Otherwise how could I wake up re-freshed, re-engaged? The pores cleared nightly. The naked face washed. Waking is re-application.
- Etymology shares this dynamic: a PIE root is the attractor; its descendant words are the orbits. *sekw-* (to follow) generates sight, sequence, sign — three trajectories of the same fundamental. The word preserves what the culture forgot. Etymology is the archaeology of psychic facticity in language.
- sin (Old English *synn*): fault, error, missing the mark. NOT primarily moral but ONTOLOGICAL. The Devil's sin is a category error: treating the image as the original, the orbit as the attractor, the cosmetic as the face.
- Forward pointer to Episode 0.2: "money as speech" — US policy doctrine that treats financial expenditure as protected expression. The economic dimension of the Antichrist IS a linguistic quality. Currency is a language — a degraded language, a language of promises, an ossified economy of signs. The full development of this thread belongs in the next episode.

---

## MOVEMENT 8: THE SEER DIES — CLOSE WITH THE POEM

### READ — "Who Am I?" (line 64):

> How is it we could overturn this situation and initiate ourselves out of his world? I say that we must come to wonder who we are, and buy into no answer the Devil tries to sell us. We must learn to watch the Devil at work in the shadows of our need, and learn to need him not. Let the heart earnestly and diligently wonder "Who am I?". The Devil has a great deal of care in his shrivelled heart, for he, like us, wants to know who he is. But his deepest confusion is in believing that "wanting to know who he is" is equivalent to "just wanting to be me". Because he is more than he can let himself conceive or accept of himself, "me" will never amount to "his" Self. This is true for us too — what we are in our deepest Being goes far beyond what we could ever think of ourselves — settling for "me" cuts out our deeper identity as "that which Is", the unqualified "I AM". The heart already knows how to answer the question "who am I?" — with silent Presence, and indeed has already answered. Language and thought, it knows, have no purchase here. It is then the task of the mind to hear this response and accept it, respect it. This will clear the clouds from the sky of Presence, and who you are will be clear. Then, in the empty space of your own Self, "that which is" will have a vessel in which to pour its greater life, its fullness and satisfaction.

### Context:

- "Realise the seer dies when faced with mind's reflected sight" — the poem's climax enacted. The ego-seer dissolves when it sees itself in its own constructions. This is Answer to Job in miniature — but that development waits for 0.2.
- The Devil too "wants to know who he is" — his longing is genuine. But he confuses "wanting to know who he is" with "just wanting to be me." The archetype-as-such cannot be captured by any image — including the self-image. The Devil's failure IS the identification of the archetype with the image.
- The "Who am I?" practice as the counter-move: it dissolves the image without destroying the archetype. The self falls away; the Self remains. The seer dies; the seeing continues.
- "Language and thought have no purchase here" — the naked face beneath all words, all cosmetics, all embellishment. The sheet beneath the score. The silence beneath all utterance.

### CLOSE — Read the poem again:

> *Words reveal and re-conceal the real — they make up the makeup that adorns the face of the world, and at best accentuate and enhance the natural contours of its beauty, at worst comfort it into a clownish facade — words when cleared from the pores reveal the sheet beneath the score — words reapplied where cleanliness is denied weave a bandage over sores — re-presenting for disguise, naked bare with no surprise, realise the seer dies when faced with mind's reflected sight*

---

## PERSONAL CODA

- The retreat moment: the I-image that "used language, and expression more generally, to serve its end of crafting recognition for the reality of its image" — recognising the Devil's fabrication as one's own daily practice. The snake coiled around the heart.
- Or: the moment the images — baby, devil, puppet, Christ — all came through the same sitting, the same cushion, the same awareness. The spectral nature of the archetype experienced directly: not one image but a STREAM of images, each morphing into the next, all orbiting something that has no image at all.

---

## FULL PASSAGES USED IN THIS EPISODE

1. **"On Being Seen"** — line 20
2. **"What Is the Anti-Christ?"** — line 243
3. **"The Emptiness of the Symbol"** — line 282
4. **"The Showman"** — line 224
5. **"The Gifted Child and His Playmates"** — lines 170–176
6. **"The Hermaphrodite"** — line 60
7. **"The Devil Needs Compassion / Leaving the Parents"** — lines 36–37
8. **"The Divided Individual"** — line 42
9. **"The Fear of Formlessness"** — line 44
10. **"The Anti-Spectral Rigidity"** — line 116
11. **"Salt and Pepper"** — line 39
12. **"Child of War"** — line 61
13. **"Making Up vs. Creating"** — line 27
14. **"The Icing and the Cake"** — line 29
15. **"Who Am I?"** — line 64

**Previously used in Episode 0.0 (not repeated):**
- Symbological Contemplation (line 41)
- Compassion Throne (line 92)
- Good Man / Bad Man (lines 289–293)
- Hermit Image (line 3)

**Held for Episode 0.2:**
- Answer to Job / Aion (line 93)
- Collective Dimension (line 158)
- "You Are Dead to Me" (line 152)
- The Two Brothers (lines 227–231)
- Symbol of Suffering and Mergence (line 149)
- Thrownness and Compassion (line 94)
- The Mono-Poly (line 146)
- "What Does the Devil Long For?" (line 95)
